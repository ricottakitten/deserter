Example survivor for the RoRR Modding Toolkit

Documentation can be found [here](https://github.com/RoRRModdingToolkit/RoRR_Modding_Toolkit/wiki).

The source code can be found [here](https://github.com/RoRRModdingToolkit/RoRR_Modding_Toolkit/tree/Gabriel/_Examples/Survivor)

This example shows you how to set up your custom survivor.

If you have any additional questions, be sure to reach out in the [Discord](https://discord.gg/VjS57cszMq).

---

### Installation Instructions
Install through the Thunderstore client or r2modman [(more detailed instructions here if needed)](https://return-of-modding.github.io/ModdingWiki/Playing/Getting-Started/).  
Join the [Return of Modding server](https://discord.gg/VjS57cszMq) for support.  